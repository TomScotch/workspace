/**
 * @author weism
 * @copyright 2015 Qcplay All Rights Reserved.
 *
 * 所有的文本
 */

/**
 * key为en，value为各种语言的翻译
 */
module.exports = {
};
